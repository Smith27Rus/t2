<?php
return [
    'neuro' => [
        'key'   => 'neuro',
        'title' => 'Центр неврологии «Клевер»',
    ],
    'speech' => [
        'key'   => 'speech',
        'title' => 'Центр развития речи «Клевер»',
    ],
];
